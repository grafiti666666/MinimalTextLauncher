# Minimal Text Launcher

Ein extrem reduzierter Android-Launcher:

- schwarzer Hintergrund
- **erster Listenpunkt ist der aktuelle Batteriestand in Prozent**
- danach die startbaren Apps alphabetisch
- weiße, schlichte Android-Systemschrift
- vertikal scrollbar
- App-Namen als klickbarer Text
- keine Icons, Suche, Widgets, Werbung oder sonstige UI-Elemente
- Batteriestand aktualisiert sich automatisch bei Änderungen

## Verwendung

Projekt in Android Studio öffnen und auf einem Android-Gerät ausführen.
Danach unter **Einstellungen → Apps → Standard-Apps → Home-App** den Minimal Text Launcher auswählen.
