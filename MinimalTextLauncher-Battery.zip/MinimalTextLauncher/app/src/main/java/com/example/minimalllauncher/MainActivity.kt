package com.example.minimalllauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.Collator
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var batteryText: TextView

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) updateBattery(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(28), dp(18), dp(28), dp(24))
        }
        scroll.addView(list, ScrollView.LayoutParams(-1, -2))
        setContentView(scroll)
        loadApps()
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStop() {
        unregisterReceiver(batteryReceiver)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) loadApps()
    }

    private fun loadApps() {
        list.removeAllViews()
        batteryText = TextView(this).apply {
            text = batteryPercentageFromStickyIntent()
            textSize = 22f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            setPadding(0, dp(10), 0, dp(10))
            minHeight = dp(48)
            isClickable = false
            isFocusable = false
        }
        list.addView(batteryText, LinearLayout.LayoutParams(-1, -2))

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedWith(compareBy(Collator.getInstance(Locale.getDefault())) { it.loadLabel(packageManager).toString() })

        for (info in apps) {
            val label = info.loadLabel(packageManager).toString()
            val pkg = info.activityInfo.packageName
            val activity = info.activityInfo.name
            val item = TextView(this).apply {
                text = label
                textSize = 22f
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                includeFontPadding = false
                setPadding(0, dp(10), 0, dp(10))
                minHeight = dp(48)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    try {
                        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(pkg, activity).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) { }
                }
            }
            list.addView(item, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun batteryPercentageFromStickyIntent(): String {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        return if (intent != null) batteryPercentage(intent) else "– %"
    }

    private fun updateBattery(intent: Intent) {
        if (::batteryText.isInitialized) batteryText.text = batteryPercentage(intent)
    }

    private fun batteryPercentage(intent: Intent): String {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        return if (percent >= 0) "$percent %" else "– %"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()
}
