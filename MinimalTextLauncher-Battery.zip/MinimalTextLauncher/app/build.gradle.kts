plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.example.minimalllauncher"; compileSdk = 35
    defaultConfig { applicationId = "com.example.minimalllauncher"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
