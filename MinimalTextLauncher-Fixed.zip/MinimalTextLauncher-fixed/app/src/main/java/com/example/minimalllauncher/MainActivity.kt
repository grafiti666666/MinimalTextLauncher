package com.example.minimalllauncher

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.Collator
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var batteryView: TextView

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val level = intent?.getIntExtra("level", -1) ?: -1
            val scale = intent?.getIntExtra("scale", 100) ?: 100
            if (level >= 0 && scale > 0) {
                val percent = (level * 100 / scale)
                batteryView.text = "$percent %"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
        }

        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        batteryView = makeTextView().apply {
            text = "-- %"
            textSize = 22f
        }
        listContainer.addView(batteryView)

        scroll.addView(listContainer, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)

        loadApps()
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStop() {
        unregisterReceiver(batteryReceiver)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    private fun loadApps() {
        if (!::listContainer.isInitialized) return
        while (listContainer.childCount > 1) {
            listContainer.removeViewAt(1)
        }

        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .sortedWith(compareBy(Collator.getInstance(Locale.getDefault())) { it.loadLabel(packageManager).toString() })

        for (resolveInfo in apps) {
            val label = resolveInfo.loadLabel(packageManager).toString()
            val packageName = resolveInfo.activityInfo.packageName
            val activityName = resolveInfo.activityInfo.name

            val row = makeTextView().apply {
                text = label
                setOnClickListener {
                    val launchIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                        setClassName(packageName, activityName)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                        // Ignore apps that cannot be launched.
                    }
                }
            }
            listContainer.addView(row)
        }
    }

    private fun makeTextView(): TextView = TextView(this).apply {
        setTextColor(Color.WHITE)
        setTextSize(20f)
        gravity = Gravity.CENTER_VERTICAL
        includeFontPadding = true
        setPadding(0, dp(8), 0, dp(8))
        layoutParams = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
